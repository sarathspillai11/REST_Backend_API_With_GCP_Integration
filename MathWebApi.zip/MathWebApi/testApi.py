from requests import put, get

welcomeMessage=get('http://localhost:5000/').json()
print(welcomeMessage)

fibonacciResponse=put('http://127.0.0.1:5000/fibonacci/',data={'count':"10"}).json()
print(fibonacciResponse)
ackermannResponse=put('http://127.0.0.1:5000/ackermann/',data={'m':"2",'n':"10"}).json()
print(ackermannResponse)
factorialResponse=put('http://127.0.0.1:5000/factorial/',data={'n':"6"}).json()
print(factorialResponse)
